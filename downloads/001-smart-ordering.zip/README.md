# Project 001 — Smart Ordering & Kitchen Operations Dashboard

A browser-only business software demonstration that connects a customer ordering interface to an operational preparation dashboard.

## What it demonstrates

- Responsive digital menu
- Category filtering and search
- Cart quantity controls
- Demo checkout flow
- Customer/table information
- Simulated order creation
- Operations states: Incoming → Preparing → Ready → Completed
- Live workflow metrics and completed-order sales total
- Mobile-friendly layout
- No paid service or backend dependency

## Technology

- HTML
- CSS
- Vanilla JavaScript

The project is intentionally packaged as a single `index.html` file so visitors can download it, inspect it quickly and run it locally.

## Professional scope

This is a portfolio and educational business-software workflow demo. It does not process real payments, authenticate production staff, persist production orders to a database, or replace a real POS/operations system.
