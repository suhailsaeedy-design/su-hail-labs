# Project 002 — Interactive 3D Network Operations Lab

A browser-only interactive network visualization for learning topology, device roles, traffic paths, monitoring states and incident simulation.

## Features
- Drag-to-orbit 3D-style topology
- Mouse/trackpad zoom
- Animated packet traffic
- Device inspector
- Online / warning / down status model
- Simulated latency alert and recovery
- Responsive desktop/mobile interface
- Zero paid dependencies

## Technology
- HTML
- CSS
- Vanilla JavaScript
- Canvas 2D projection and animation

## Educational scope
This is a simplified learning and portfolio visualization. It is not a production network architecture, security configuration, or operational monitoring system.
